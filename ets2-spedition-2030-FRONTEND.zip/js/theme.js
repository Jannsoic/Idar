
document.getElementById("themeToggle").onclick=()=>{
 document.body.classList.toggle("light");
};
